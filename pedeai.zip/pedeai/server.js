const http=require('http'),fs=require('fs'),path=require('path');
const PORT=process.env.PORT||3000,FILE=path.join(__dirname,'data.json'),COMPANY_FILE=path.join(__dirname,'company.json'),HTML=path.join(__dirname,'public','index.html');
const DEF={config:{menu:[{id:1,name:'X-Burger',desc:'Pão, blend 160g e queijo',price:28.9,cat:'Lanches',emoji:'🍔',on:true},{id:2,name:'Refrigerante Lata',desc:'350 ml',price:6.5,cat:'Bebidas',emoji:'🥤',on:true}],zones:[{id:1,name:'Centro',fee:5,on:true}],store:{name:'PedeAí',open:true,city:'',pinR:'1234',pinE:'0000'}},orders:{}};
const DEFAULT_LANDING={brand:'PedeAí',title:'Seu restaurante merece uma operação mais simples.',description:'Cardápio digital, pedidos e entregas em um só lugar. Mais organização para você e mais praticidade para seus clientes.',cta:'Quero conhecer',whatsapp:'',email:'',instagram:'',features:[{title:'Pedidos organizados',text:'Acompanhe cada pedido e seu andamento em um só painel.'},{title:'PDV integrado',text:'Registre vendas de mesa, retirada e entrega com pagamento e comanda.'},{title:'Delivery conectado',text:'Organize a equipe de entrega e mantenha seus clientes informados.'}]};
const UP=path.join(__dirname,'uploads');fs.mkdirSync(UP,{recursive:true});
let D;try{D=JSON.parse(fs.readFileSync(FILE,'utf8'))}catch(e){D=JSON.parse(JSON.stringify(DEF))}
D.couriers=D.couriers||[{id:'m1',name:'Motoboy 1',phone:'',pin:'0000',on:true}];
D.customers=D.customers||[];D.sessions=D.sessions||{};D.pts=D.pts||[];D.audit=D.audit||[];D.reviews=D.reviews||[];
const legacyLanding=D.config.landing;
const save=()=>fs.writeFile(FILE,JSON.stringify(D),()=>{});
const normalizedLanding=landing=>({...DEFAULT_LANDING,...(landing||{}),features:Array.isArray(landing&&landing.features)?landing.features:DEFAULT_LANDING.features});
let COMPANY;
try{COMPANY=normalizedLanding(JSON.parse(fs.readFileSync(COMPANY_FILE,'utf8')))}catch(e){COMPANY=normalizedLanding(legacyLanding)}
const saveCompany=()=>fs.writeFileSync(COMPANY_FILE,JSON.stringify(COMPANY));
if(!fs.existsSync(COMPANY_FILE)&&legacyLanding)saveCompany();
if(Object.prototype.hasOwnProperty.call(D.config,'landing')){delete D.config.landing;save()}
const COMPANY_ADMIN_PASSWORD=String(process.env.COMPANY_ADMIN_PASSWORD||''),companyAdminSessions=new Map(),companyAdminFailures=new Map();
const isCompanyAdmin=req=>{
 const token=String(req.headers['x-company-token']||''),session=companyAdminSessions.get(token);
 if(!session)return false;
 if(session<=Date.now()){companyAdminSessions.delete(token);return false}
 return true;
};
const clients=new Set(),notify=()=>clients.forEach(r=>r.write('data: 1\n\n'));
setInterval(()=>clients.forEach(r=>r.write(':\n\n')),25000);
const ST=()=>D.config.store;
const who=pin=>{if(!pin)return null;if(pin===ST().pinR)return {r:'r'};const c=D.couriers.find(c=>c.on&&c.pin===pin);return c?{r:'e',c}:null};
const send=(res,c,o)=>{res.writeHead(c,{'content-type':'application/json'});res.end(JSON.stringify(o))};
const readBody=(req,lim=2e5)=>new Promise(ok=>{let b='';req.on('data',c=>{b+=c;if(b.length>lim)req.destroy()});req.on('end',()=>{try{ok(JSON.parse(b||'{}'))}catch(e){ok({})}})});
const num=v=>typeof v=='number'&&isFinite(v);
const rc=new Map();
const GMAPS_KEY=process.env.GOOGLE_MAPS_KEY||'AIzaSyCqQCo7xgXAX3HRFu9NHkLsTKs6ojnx1e0';
function decPoly(str){
 let idx=0,lat=0,lng=0,res=[];
 while(idx<str.length){
  let b,shift=0,r=0;do{b=str.charCodeAt(idx++)-63;r|=(b&0x1f)<<shift;shift+=5}while(b>=0x20);
  lat+=((r&1)?~(r>>1):(r>>1));shift=0;r=0;
  do{b=str.charCodeAt(idx++)-63;r|=(b&0x1f)<<shift;shift+=5}while(b>=0x20);
  lng+=((r&1)?~(r>>1):(r>>1));res.push([lat*1e-5,lng*1e-5]);
 }
 return res;
}
async function route(f,t){
 const k=f+'|'+t,c=rc.get(k);if(c&&Date.now()-c.t<20000)return c.v;
 const [a,b]=[f,t].map(s=>String(s).split(',').map(Number));if([...a,...b].length!=4||[...a,...b].some(isNaN))return {};
 if(GMAPS_KEY){
  try{
   const gr=await fetch(`https://maps.googleapis.com/maps/api/directions/json?origin=${a[0]},${a[1]}&destination=${b[0]},${b[1]}&mode=driving&key=${GMAPS_KEY}`);
   const gj=await gr.json();
   if(gj.status=='OK'&&gj.routes&&gj.routes[0]){
    const r0=gj.routes[0],l0=r0.legs[0],coords=decPoly(r0.overview_polyline.points);
    const v={coords,dur:l0.duration.value,dist:l0.distance.value};
    rc.set(k,{t:Date.now(),v});return v;
   }
  }catch(ge){}
 }
 const r=await fetch(`https://router.project-osrm.org/route/v1/driving/${a[1]},${a[0]};${b[1]},${b[0]}?overview=full&geometries=geojson`);
 const x=((await r.json()).routes||[])[0];
 const v=x?{coords:x.geometry.coordinates.map(p=>[p[1],p[0]]),dur:x.duration,dist:x.distance}:{};
 rc.set(k,{t:Date.now(),v});return v}
const crypto=require('crypto');
const hp=(pw,salt)=>crypto.scryptSync(pw,salt,64).toString('hex');
const dig=s=>String(s||'').replace(/\D/g,''),okPhone=s=>{const d=dig(s);return d.length>=10&&d.length<=13};
const pub=({salt,hash,...c})=>({...c,hasPw:!!hash}),fails=new Map();
const cu=t=>{const s=D.sessions[t];return s&&Date.now()-s.t<7.8e9?D.customers.find(c=>c.id==s.cid):null};
const sess=c=>{const t=crypto.randomBytes(24).toString('hex');D.sessions[t]={cid:c.id,t:Date.now()};save();return t};
const rnd=()=>Math.random().toString(36).slice(2,12)+Date.now().toString(36),MAXB=(+process.env.AUDIO_MAX_MB||4)*1e6,MAXS=+process.env.AUDIO_MAX_SEC||15;
const LBL={novo:'Recebido',preparando:'Em preparo',pronto:'Aguardando entregador',a_caminho:'Saiu para entrega',entregue:'Entregue',cancelado:'Cancelado'},ORD=['novo','preparando','pronto','a_caminho','entregue'];
const hist=(o,ev,by,why)=>{(o.hist=o.hist||[]).push({t:Date.now(),ev,by,why:why||undefined})};
const cad=a=>{a=a||{};const s=(k,n)=>String(a[k]||'').trim().slice(0,n);return {cep:dig(a.cep).slice(0,8),street:s('street',120),num:s('num',12),comp:s('comp',60),bairro:s('bairro',60),city:s('city',60),uf:s('uf',2).toUpperCase(),ref:s('ref',120)}};
const LOY=()=>ST().loy2||{};
const BRT=t=>{const d=new Date(new Date(t).toLocaleString('en-US',{timeZone:'America/Sao_Paulo'})),z=n=>String(n).padStart(2,'0');return {ymd:d.getFullYear()+'-'+z(d.getMonth()+1)+'-'+z(d.getDate()),dow:d.getDay(),hm:z(d.getHours())+':'+z(d.getMinutes())}};
const camp=o=>{const b=BRT(o.createdAt);let m=1;(LOY().camps||[]).forEach(c=>{if(c.on===false||(c.from&&b.ymd<c.from)||(c.to&&b.ymd>c.to)||((c.dows||[]).length&&!c.dows.includes(b.dow))||(c.hFrom&&b.hm<c.hFrom)||(c.hTo&&b.hm>c.hTo)||(+c.minOrder>0&&o.sub-(o.disc||0)<+c.minOrder))return;m=Math.max(m,+c.mult||1)});return m};
const pts=uid=>D.pts.filter(e=>e.uid==uid).sort((a,b)=>a.t-b.t);
const lstate=uid=>{const lots=[],now=Date.now();for(const e of pts(uid)){if(e.pts>0)lots.push({r:e.pts,exp:e.exp||Infinity,e});else{let need=-e.pts;for(const l of lots){if(l.exp<=e.t||!l.r)continue;const x=Math.min(l.r,need);l.r-=x;need-=x;if(!need)break}}}
 return {bal:lots.filter(l=>l.exp>now).reduce((a,l)=>a+l.r,0),expired:lots.filter(l=>l.exp<=now).reduce((a,l)=>a+l.r,0),ex:lots.filter(l=>l.exp<=now&&l.r>0).map(l=>({t:l.exp,pts:l.r})),soon:lots.filter(l=>l.exp>now&&l.exp-now<7*864e5&&l.r>0).map(l=>({pts:l.r,exp:l.exp}))}};
const addP=(uid,type,p,ref,note,by,exp)=>{const e={id:rnd(),uid,t:Date.now(),type,pts:p,ref,note,by,exp};D.pts.push(e);return e};
const expAt=()=>LOY().expD>0?Date.now()+LOY().expD*864e5:undefined;
const earnOrder=o=>{const L=LOY();if(!L.on||!o.uid||o.pe)return;const base=o.sub-(o.disc||0),m=camp(o);let p=L.mode=='order'?(+L.pts||0):Math.floor(base*(+L.pts||0));p=Math.round(p*m);if(p<=0)return;o.pe=addP(o.uid,'earn',p,o.id,'Pedido #'+o.num+(m>1?' (campanha x'+m+')':''),'Sistema',expAt()).id;o.pp=p};
const revOrder=o=>{if(!o.pe)return;const p=Math.min(o.pp||0,lstate(o.uid).bal);if(p>0)addP(o.uid,'reverse',-p,o.id,'Estorno de pontos do pedido #'+o.num,'Sistema');o.pe=null;o.pp=0};
const refOrder=o=>{if(!o.redeem||o.rfd)return;o.rfd=true;addP(o.uid,'refund',o.redeem.cost,o.id,'Resgate devolvido (pedido #'+o.num+' cancelado)','Sistema',expAt())};
const loyHook=(o,prev,to)=>{if(to=='entregue')earnOrder(o);if(prev=='entregue'&&to!='entregue')revOrder(o);if(to=='cancelado')refOrder(o)};
const payHook=(o,prev,to)=>{if(!o.pay)return;if(to=='cancelado'){if(o.pay.st=='pago'){o.pay.st='estornar';hist(o,'Reembolso pendente','Sistema')}else if(o.pay.st=='pendente')o.pay.st='sem cobrança'}
 if(to=='entregue'&&o.pay.m!='pix'&&o.pay.st=='pendente'&&(!o.fulfillment||o.fulfillment=='delivery')){o.pay.st='pago';o.pay.paid=o.total;o.pay.at=Date.now();hist(o,'Pagamento recebido na entrega','Sistema')}};
const isC=m=>m.combo&&m.combo.length;
const pr=(m,reg)=>{if(isC(m)){const s=m.combo.reduce((a,c)=>{const x=D.config.menu.find(k=>k.id==c.id);return a+(x&&!isC(x)?pr(x,reg)[0]*c.q:0)},0);return [Math.round(s*(1-(m.cdisc||0)/100)*100)/100,m.cdisc>0?s:0]}return m.promo>0&&m.promo<m.price&&(!m.promoEx||reg)?[m.promo,m.price]:[m.price,0]};
const av=m=>m.on&&(!isC(m)||m.combo.every(c=>{const x=D.config.menu.find(k=>k.id==c.id);return x&&x.on&&!isC(x)}));
http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://x'),p=u.pathname,W=who(req.headers['x-pin']),r=W&&W.r,U=cu(req.headers['x-tok']),cid=r=='e'?W.c.id:U?'u'+U.id:String(req.headers['x-cid']||'').slice(0,60),M=req.method;
 try{
  if(p=='/api/stream'){res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache',connection:'keep-alive'});res.write('retry: 3000\n\n');clients.add(res);req.on('close',()=>clients.delete(res));return}
  if(p=='/api/state'){
   const {pinR,pinE,...store}=ST(),all=Object.values(D.orders);
   const orders=(r=='r'?all:r=='e'?all.filter(o=>['preparando','pronto','a_caminho','entregue'].includes(o.status)&&(!o.courier||o.courier==cid)):all.filter(o=>o.cid&&o.cid==cid)).sort((a,b)=>a.createdAt-b.createdAt);
   const revList=D.reviews||[],reviews=r=='r'?revList:(r=='e'?revList.filter(x=>x.courierId==cid&&!x.hidden):revList.filter(x=>!x.hidden));
   return send(res,200,{config:{menu:D.config.menu,zones:D.config.zones,store:{...store,googleId:process.env.GOOGLE_CLIENT_ID||''}},orders:r=='r'?orders:orders.map(o=>({...o,hist:(o.hist||[]).map(h=>({t:h.t,ev:h.ev}))})),couriers:r=='r'?D.couriers.map(({pin,...c})=>c):undefined,me:r=='e'?{id:W.c.id,name:W.c.name,duty:!!W.c.duty}:undefined,customers:r=='r'?D.customers.map(pub):undefined,reviews})}
  if(p=='/api/landing'&&M=='GET')return send(res,200,COMPANY);
  if(p=='/api/landing/login'&&M=='POST'){
   if(COMPANY_ADMIN_PASSWORD.length<12)return send(res,503,{error:'Configure uma senha administrativa com pelo menos 12 caracteres em COMPANY_ADMIN_PASSWORD'});
   const ip=String(req.socket.remoteAddress||''),now=Date.now(),state=companyAdminFailures.get(ip)||{count:0,since:now};
   if(now-state.since>15*60*1000){state.count=0;state.since=now}
   if(state.count>=8){companyAdminFailures.set(ip,state);return send(res,429,{error:'Muitas tentativas. Aguarde 15 minutos.'})}
   const b=await readBody(req),password=String(b.password||'');
   const supplied=Buffer.from(password),configured=Buffer.from(COMPANY_ADMIN_PASSWORD),valid=supplied.length===configured.length&&crypto.timingSafeEqual(supplied,configured);
   if(!valid){state.count++;companyAdminFailures.set(ip,state);return send(res,401,{error:'Senha administrativa incorreta'})}
   companyAdminFailures.delete(ip);const token=crypto.randomBytes(32).toString('hex');companyAdminSessions.set(token,now+12*60*60*1000);
   return send(res,200,{token})
  }
  if(p=='/api/landing/admin'&&M=='GET'){
   if(COMPANY_ADMIN_PASSWORD.length<12)return send(res,503,{error:'Configure COMPANY_ADMIN_PASSWORD com pelo menos 12 caracteres'});
   if(!isCompanyAdmin(req))return send(res,401,{error:'Sessão administrativa expirada'});
   return send(res,200,COMPANY)
  }
  if(p=='/api/landing/logout'&&M=='POST'){
   companyAdminSessions.delete(String(req.headers['x-company-token']||''));return send(res,200,{ok:1})
  }
  if(p=='/api/landing'&&M=='PUT'){
   if(!isCompanyAdmin(req))return send(res,401,{error:'Acesse o painel administrativo da empresa para salvar alterações'});
   const b=await readBody(req),text=(v,max)=>String(v||'').trim().slice(0,max),bad=m=>send(res,400,{error:m});
   const features=Array.isArray(b.features)?b.features.slice(0,3).map(f=>({title:text(f&&f.title,50),text:text(f&&f.text,160)})):[];
   if(!text(b.brand,40)||!text(b.title,110)||!text(b.description,350)||!text(b.cta,45)||features.length!=3||features.some(f=>!f.title||!f.text))return bad('Preencha marca, chamada, descrição e os três serviços');
   const whatsapp=text(b.whatsapp,30),email=text(b.email,120),instagram=text(b.instagram,180);
   if(whatsapp&&!/^[+\d\s().-]{8,30}$/.test(whatsapp))return bad('Informe um WhatsApp válido com DDD');
   if(email&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))return bad('E-mail comercial inválido');
   if(instagram&&!/^(https:\/\/(www\.)?instagram\.com\/|@[A-Za-z0-9._]{1,30}$)/i.test(instagram))return bad('Informe um perfil ou link válido do Instagram');
   COMPANY={brand:text(b.brand,40),title:text(b.title,110),description:text(b.description,350),cta:text(b.cta,45),whatsapp,email,instagram,features};
   saveCompany();return send(res,200,COMPANY)}
  if(p=='/api/login'&&M=='POST'){const b=await readBody(req);const w=who(String(b.pin||''));return send(res,200,{role:w?w.r:null})}
  if(p=='/api/order'&&M=='POST'){
   const b=await readBody(req);if(!ST().open||!cid)return send(res,400,{error:'Restaurante fechado'});
   const z=D.config.zones.find(z=>z.on&&z.name==b.zone);
   const gst=b.guest||{},cname=U?U.name:String(gst.name||'').trim().slice(0,60),cphone=U?U.phone:dig(gst.phone);
   const items=(Array.isArray(b.items)?b.items:[]).map(i=>{const m=D.config.menu.find(m=>m.id==i.id),q=Math.floor(i.q);if(!m||!av(m)||!(q>0&&q<100))return null;
    let ex=0;const ot=[],gs=m.opts||[];
    for(let g=0;g<gs.length;g++){const G=gs[g],raw=((i.sel||[])[g]||[]).map(Number),cnt={};
     for(const x of raw){if(!(x>=0&&x<G.ch.length)||G.ch[x].on===false)return null;cnt[x]=(cnt[x]||0)+1}
     const ks=Object.keys(cnt),tot=raw.length;
     if(ks.some(k=>cnt[k]>(G.multi?(+G.ch[k].qmax||1):1))||(!G.multi&&tot>1)||(G.multi&&G.max>0&&tot>G.max)||tot<Math.max(+G.min||0,G.req?1:0))return null;
     if(tot){ot.push(G.name+': '+ks.map(k=>G.ch[k].n+(cnt[k]>1?' x'+cnt[k]:'')).join(', '));ex+=ks.reduce((a,k)=>a+(+G.ch[k].p||0)*cnt[k],0)}}
    const nt=String(i.note||'').trim(),nmax=m.noteMax==null?140:+m.noteMax;if(nt.length>nmax)return null;
    const o={mid:m.id,name:m.name,q,price:Math.round((pr(m,!!U)[0]+ex)*100)/100};if(ot.length)o.opt=ot.join(' · ');if(nt)o.note=nt;
    if(isC(m))o.inc=m.combo.map(c=>c.q+'× '+D.config.menu.find(k=>k.id==c.id).name);return o});
   if(!z||!items.length||items.includes(null)||!cname||!okPhone(cphone)||!b.addr||!num(b.lat)||!num(b.lng))return send(res,400,{error:'Pedido inválido'});
   const PY=ST().pay||{},pm=b.pay&&b.pay.m;if(!['pix','card','cash'].includes(pm)||PY[pm]===false)return send(res,400,{error:'Forma de pagamento indisponível'});
   let disc=0,ship0=false,redeem=null;
   if(b.redeem){const L=LOY(),rw2=(L.rewards||[]).find(x=>x.id==b.redeem),E=m=>send(res,400,{error:m});
    if(!U||!L.on||!rw2||rw2.on===false)return E('Recompensa indisponível');
    const subT=items.reduce((a,i)=>a+i.q*i.price,0);
    if(rw2.until&&BRT(Date.now()).ymd>rw2.until)return E('Recompensa expirada');
    if(lstate(U.id).bal<Math.max(+L.min||0,+rw2.cost||0))return E('Saldo de pontos insuficiente');
    if(+rw2.minOrder>subT)return E('Esta recompensa exige pedido mínimo de R$ '+(+rw2.minOrder).toFixed(2).replace('.',','));
    const used=Object.values(D.orders).filter(x=>x.redeem&&x.redeem.rid==rw2.id&&x.status!='cancelado');
    if(+rw2.limit>0&&used.length>=rw2.limit)return E('Recompensa esgotada');
    if(+rw2.limitC>0&&used.filter(x=>x.uid==U.id).length>=rw2.limitC)return E('Você atingiu o limite de resgates desta recompensa');
    const el=(rw2.prods||[]).length?items.filter(i=>rw2.prods.includes(i.mid)):items,elS=el.reduce((a,i)=>a+i.q*i.price,0);
    if(rw2.type=='pct'||rw2.type=='fixed'){if(!el.length)return E('Esta recompensa vale só para produtos específicos que não estão no pedido');disc=rw2.type=='pct'?Math.round(elS*(+rw2.val||0))/100:Math.min(elS,+rw2.val||0)}
    else if(rw2.type=='ship')ship0=true;
    else if(rw2.type=='prod'){const gm=D.config.menu.find(m=>m.id==rw2.prod);if(!gm||!av(gm)||(gm.opts||[]).some(g=>g.req||g.min>0))return E('Brinde indisponível no momento');items.push({mid:gm.id,name:gm.name,q:Math.max(1,+rw2.qty||1),price:0,gift:true})}
    redeem={rid:rw2.id,name:rw2.name,type:rw2.type,cost:+rw2.cost||0}}
   let rw=null;
   if(b.reward){const N=+ST().loyN||0,mo=U?Object.values(D.orders).filter(o=>o.uid==U.id):[];
    if(!U||N<1||Math.floor(mo.filter(o=>o.status=='entregue').length/N)-mo.filter(o=>o.reward&&o.status!='cancelado').length<1)return send(res,400,{error:'Você não tem brinde de fidelidade disponível'});
    rw=ST().loyReward||'Brinde fidelidade'}
   const sub=items.reduce((a,i)=>a+i.q*i.price,0),now=Date.now(),tot=Math.round((Math.max(0,sub-disc)+(ship0?0:z.fee))*100)/100,chg=pm=='cash'&&+b.pay.change>0?+b.pay.change:null;
   if(chg&&chg<tot)return send(res,400,{error:'O troco deve ser para um valor maior ou igual ao total'});
   const pay={m:pm,change:chg,st:'pendente',paid:0};
   const o={id:'o'+now.toString(36)+Math.random().toString(36).slice(2,5),num:String(now%100000).padStart(5,'0'),cid,createdAt:now,items,sub,disc,fee:z.fee,ship0,total:tot,name:cname,phone:dig(cphone),uid:U?U.id:null,reward:rw,redeem,pay,addr:String(b.addr).slice(0,160),zone:z.name,lat:b.lat,lng:b.lng,status:'novo',hist:[{t:now,ev:'Pedido criado',by:cname}],ad:{...cad(b.ad),lat:b.lat,lng:b.lng},time:new Date(now).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit',timeZone:'America/Sao_Paulo'})};
   D.orders[o.id]=o;if(redeem)addP(U.id,'redeem',-redeem.cost,o.id,'Resgate: '+redeem.name+' (pedido #'+o.num+')','Cliente');save();notify();return send(res,200,o)}
  if(p=='/api/pos-order'&&M=='POST'){
   const b=await readBody(req),bad=m=>send(res,400,{error:m});
   if(r!='r')return send(res,401,{error:'Não autorizado'});
   const fulfillment=['mesa','retirada','delivery'].includes(b.fulfillment)?b.fulfillment:null;
   if(!fulfillment||!Array.isArray(b.items)||!b.items.length||b.items.some(i=>!i||typeof i!='object'))return bad('Informe o tipo de atendimento e os itens');
   const items=b.items.map(i=>{
    const m=D.config.menu.find(x=>x.id==i.id),q=Math.floor(+i.q);
    if(!m||!av(m)||!(q>0&&q<100)||(i.sel!=null&&!Array.isArray(i.sel)))return null;
    let ex=0;const ot=[],gs=m.opts||[];
    for(let g=0;g<gs.length;g++){
     const G=gs[g],selected=i.sel?i.sel[g]:undefined;if(selected!=null&&!Array.isArray(selected))return null;
     const raw=selected?selected.map(Number):[],cnt={};
     for(const x of raw){if(!(x>=0&&x<G.ch.length)||G.ch[x].on===false)return null;cnt[x]=(cnt[x]||0)+1}
     const ks=Object.keys(cnt),tot=raw.length;
     if(ks.some(k=>cnt[k]>(G.multi?(+G.ch[k].qmax||1):1))||(!G.multi&&tot>1)||(G.multi&&G.max>0&&tot>G.max)||tot<Math.max(+G.min||0,G.req?1:0))return null;
     if(tot){ot.push(G.name+': '+ks.map(k=>G.ch[k].n+(cnt[k]>1?' x'+cnt[k]:'')).join(', '));ex+=ks.reduce((a,k)=>a+(+G.ch[k].p||0)*cnt[k],0)}
    }
    const nt=String(i.note||'').trim(),nmax=m.noteMax==null?140:+m.noteMax;if(nt.length>nmax)return null;
    const item={mid:m.id,name:m.name,q,price:Math.round((pr(m,false)[0]+ex)*100)/100};
    if(ot.length)item.opt=ot.join(' · ');if(nt)item.note=nt;
    if(isC(m))item.inc=m.combo.map(c=>c.q+'× '+D.config.menu.find(k=>k.id==c.id).name);
    return item;
   });
   if(items.includes(null))return bad('Um ou mais itens ou adicionais estão indisponíveis');
   const zone=fulfillment=='delivery'?D.config.zones.find(z=>z.on&&z.name==b.zone):null;
   if(fulfillment=='delivery'&&(!zone||!String(b.addr||'').trim()))return bad('Informe um endereço e um bairro de entrega válido');
   const name=String(b.name||'Cliente balcão').trim().slice(0,60)||'Cliente balcão',phone=dig(b.phone).slice(0,13);
   const sub=Math.round(items.reduce((a,i)=>a+i.q*i.price,0)*100)/100,rawDisc=b.discount==null||b.discount===''?0:Number(b.discount),disc=Math.round(rawDisc*100)/100;
   if(!Number.isFinite(rawDisc)||disc<0||disc>sub)return bad('Desconto inválido');
   const fee=zone?+zone.fee||0:0,total=Math.round((sub-disc+fee)*100)/100,pm=b.pay&&b.pay.m;
   if(!['pix','card','cash'].includes(pm)||(ST().pay||{})[pm]===false)return bad('Forma de pagamento indisponível');
   const rawChange=b.pay.change==null||b.pay.change===''?0:Number(b.pay.change),change=pm=='cash'&&rawChange>0?Math.round(rawChange*100)/100:null;
   if(!Number.isFinite(rawChange)||rawChange<0||(change&&change<total))return bad('O valor recebido deve ser maior ou igual ao total');
   const now=Date.now(),paid=!!(b.pay&&b.pay.paid),table=fulfillment=='mesa'?String(b.table||'').trim().slice(0,20):'';
   if(fulfillment=='mesa'&&!table)return bad('Informe o número ou identificação da mesa');
   const location=fulfillment=='mesa'?'Mesa '+table:fulfillment=='retirada'?'Retirada':zone.name;
   const o={id:'o'+now.toString(36)+Math.random().toString(36).slice(2,5),num:String(now%100000).padStart(5,'0'),cid:'pos'+rnd(),createdAt:now,items,sub,disc,fee,total,name,phone,uid:null,fulfillment,table:table||undefined,pay:{m:pm,change,st:paid?'pago':'pendente',paid:paid?total:0,...(paid?{at:now}:{})},addr:fulfillment=='delivery'?String(b.addr).trim().slice(0,160):location,zone:location,status:'novo',hist:[{t:now,ev:'Pedido criado no PDV',by:'Restaurante'}],time:BRT(now).hm};
   D.orders[o.id]=o;save();notify();return send(res,200,o)}
  if(p=='/api/patch'&&M=='POST'){
   const b=await readBody(req),o=D.orders[b.id],pt=b.patch||{},s=pt.status;
   if(!r)return send(res,401,{error:'Não autorizado'});if(!o)return send(res,404,{error:'Pedido não encontrado'});
   let ok=false;
   if(r=='r')ok=(s=='preparando'&&o.status=='novo')||(s=='pronto'&&o.status=='preparando')||(s=='cancelado'&&['novo','preparando'].includes(o.status));
   else if(Object.keys(pt).join()=='courier')ok=!o.courier&&['preparando','pronto'].includes(o.status)&&pt.courier==cid;
   else if(s=='a_caminho')ok=o.courier==cid&&o.status=='pronto';
   else if(s=='entregue')ok=o.courier==cid&&o.status=='a_caminho';
   if(!ok)return send(res,403,{error:'Ação não permitida (o pedido pode ter mudado)'});
   const prev=o.status;if(r=='e'&&pt.courier){o.courier=cid;hist(o,'Entregador aceitou: '+W.c.name,W.c.name)}if(s){o.status=s;hist(o,LBL[prev]+' → '+LBL[s],r=='r'?'Restaurante':W.c.name)}if(s=='entregue')o.dt=Date.now();if(s){loyHook(o,prev,s);payHook(o,prev,s)}save();notify();return send(res,200,o)}
  if(p=='/api/loc'&&M=='POST'){
   const b=await readBody(req);if(r!='e'||!num(b.lat)||!num(b.lng))return send(res,401,{error:'Não autorizado'});
   let n=0;(Array.isArray(b.ids)?b.ids:[]).forEach(id=>{const o=D.orders[id];if(o&&o.courier==cid&&o.status=='a_caminho'){o.cl={lat:b.lat,lng:b.lng,t:Date.now()};n++}});
   W.c.loc={lat:b.lat,lng:b.lng,t:Date.now()};save();notify();return send(res,200,{n})}
  if(p=='/api/config'&&M=='PUT'){
   const b=await readBody(req);if(r!='r')return send(res,401,{error:'Não autorizado'});
   if(!Array.isArray(b.menu)||!Array.isArray(b.zones)||!b.store)return send(res,400,{error:'Dados inválidos'});
   const ns={...ST(),...b.store};['pinR','pinE'].forEach(k=>{if(String(ns[k]||'').length<4)ns[k]=ST()[k]});
   if(JSON.stringify(ST().loy2||null)!=JSON.stringify(ns.loy2||null))D.audit.push({t:Date.now(),by:'Restaurante',ev:'Programa de fidelidade alterado (regras, recompensas ou campanhas)'});
   D.config={menu:b.menu,zones:b.zones,store:ns};save();notify();return send(res,200,{ok:1})}
  if(p=='/api/signup'&&M=='POST'){
   const b=await readBody(req),bad=m=>send(res,400,{error:m}),name=String(b.name||'').trim().slice(0,80),email=String(b.email||'').trim().toLowerCase().slice(0,120),pw=String(b.password||'');
   if(name.length<5||!name.includes(' '))return bad('Informe o nome completo');
   if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))return bad('E-mail inválido');
   if(!okPhone(b.phone))return bad('Informe um WhatsApp válido com DDD');
   if(!/^\d{4}-\d{2}-\d{2}$/.test(b.bday||'')||isNaN(Date.parse(b.bday))||Date.parse(b.bday)>Date.now())return bad('Data de aniversário inválida');
   if(pw.length<6)return bad('A senha precisa ter ao menos 6 caracteres');
   if(!b.consent)return bad('É preciso aceitar os termos para criar a conta');
   if(D.customers.some(c=>c.email==email||c.phone==dig(b.phone)))return send(res,409,{error:'E-mail ou telefone já cadastrado. Faça login.'});
   const salt=crypto.randomBytes(16).toString('hex'),c={id:Date.now().toString(36)+crypto.randomBytes(3).toString('hex'),name,email,phone:dig(b.phone),bday:b.bday,salt,hash:hp(pw,salt),createdAt:Date.now()};
   D.customers.push(c);return send(res,200,{token:sess(c),user:pub(c)})}
  if(p=='/api/signin'&&M=='POST'){
   const b=await readBody(req),k=req.socket.remoteAddress,f=fails.get(k)||{n:0,t:Date.now()};
   if(Date.now()-f.t>9e5){f.n=0;f.t=Date.now()}if(f.n>=10)return send(res,429,{error:'Muitas tentativas. Aguarde alguns minutos.'});
   const l=String(b.login||'').trim().toLowerCase(),c=D.customers.find(c=>c.email==l||(dig(l).length>=10&&c.phone==dig(l)));
   const ok=c&&c.hash&&crypto.timingSafeEqual(Buffer.from(hp(String(b.password||''),c.salt),'hex'),Buffer.from(c.hash,'hex'));
   if(!ok){f.n++;fails.set(k,f);return send(res,401,{error:'Login ou senha incorretos'})}
   return send(res,200,{token:sess(c),user:pub(c)})}
  if(p=='/api/google'&&M=='POST'){
   const b=await readBody(req),gid=process.env.GOOGLE_CLIENT_ID;if(!gid)return send(res,400,{error:'Login Google não configurado'});
   const g=await fetch('https://oauth2.googleapis.com/tokeninfo?id_token='+encodeURIComponent(String(b.credential||''))),j=await g.json();
   if(!g.ok||j.aud!==gid||!j.email||String(j.email_verified)!=='true')return send(res,401,{error:'Login Google inválido'});
   const email=j.email.toLowerCase();let c=D.customers.find(c=>c.email==email);
   if(!c){c={id:Date.now().toString(36)+crypto.randomBytes(3).toString('hex'),name:String(j.name||email).slice(0,80),email,phone:'',bday:'',google:true,createdAt:Date.now()};D.customers.push(c)}
   return send(res,200,{token:sess(c),user:pub(c)})}
  if(p=='/api/me'){
   if(!U)return send(res,401,{error:'Sessão inválida'});if(M=='GET')return send(res,200,pub(U));
   if(M=='PUT'){const b=await readBody(req),bad=m=>send(res,400,{error:m});
    if(b.name!==undefined){const n=String(b.name).trim().slice(0,80);if(n.length<5||!n.includes(' '))return bad('Informe o nome completo');U.name=n}
    if(b.email!==undefined){const e=String(b.email).trim().toLowerCase().slice(0,120);if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e))return bad('E-mail inválido');if(D.customers.some(c=>c!==U&&c.email==e))return send(res,409,{error:'E-mail já em uso'});U.email=e}
    if(b.phone!==undefined){if(!okPhone(b.phone))return bad('Informe um WhatsApp válido com DDD');if(D.customers.some(c=>c!==U&&c.phone==dig(b.phone)))return send(res,409,{error:'Telefone já em uso'});U.phone=dig(b.phone)}
    if(b.bday&&/^\d{4}-\d{2}-\d{2}$/.test(b.bday)&&Date.parse(b.bday)<=Date.now())U.bday=b.bday;
    if(Array.isArray(b.addrs)){if(b.addrs.length>10)return bad('Máximo de 10 endereços');
     const L=b.addrs.map(a=>({label:String(a.label||'').trim().slice(0,30),...cad(a),lat:num(a.lat)?a.lat:null,lng:num(a.lng)?a.lng:null,full:String(a.full||'').slice(0,200)}));
     if(L.some(a=>!a.label||!a.street||!a.num||a.lat==null||a.lng==null))return bad('Endereço inválido: informe o nome, a rua (escolhida nas sugestões) e o número');U.addrs=L}
    if(typeof b.mkt=='boolean')U.mkt=b.mkt;save();return send(res,200,pub(U))}
   if(M=='DELETE'){D.customers=D.customers.filter(c=>c!==U);Object.keys(D.sessions).forEach(t=>{if(D.sessions[t].cid==U.id)delete D.sessions[t]});save();return send(res,200,{ok:1})}}
  if(p=='/api/password'&&M=='POST'){
   const b=await readBody(req);if(!U)return send(res,401,{error:'Sessão inválida'});const nw=String(b.new||'');
   if(nw.length<6)return send(res,400,{error:'A nova senha precisa ter ao menos 6 caracteres'});
   if(U.hash&&!crypto.timingSafeEqual(Buffer.from(hp(String(b.old||''),U.salt),'hex'),Buffer.from(U.hash,'hex')))return send(res,401,{error:'Senha atual incorreta'});
   U.salt=crypto.randomBytes(16).toString('hex');U.hash=hp(nw,U.salt);save();return send(res,200,{ok:1})}
  if(p=='/api/loy'){if(!U)return send(res,401,{error:'Faça login'});const st=lstate(U.id),h=pts(U.id).map(e=>({t:e.t,type:e.type,pts:e.pts,note:e.note})).concat(st.ex.map(x=>({t:x.t,type:'expire',pts:-x.pts,note:'Pontos expirados'}))).sort((a,b)=>b.t-a.t).slice(0,100);return send(res,200,{bal:st.bal,expired:st.expired,soon:st.soon,hist:h})}
  if(p=='/api/loy/admin'){if(r!='r')return send(res,401,{error:'Não autorizado'});const bals={};D.customers.forEach(c=>{const s=lstate(c.id);bals[c.id]={bal:s.bal,expired:s.expired}});return send(res,200,{bals,ledger:D.pts.slice(-300).reverse(),audit:D.audit.slice(-50).reverse()})}
  if(p=='/api/pts/adjust'&&M=='POST'){
   const b=await readBody(req),c=D.customers.find(c=>c.id==b.uid),n=Math.trunc(+b.pts),note=String(b.note||'').trim().slice(0,200),bad=m=>send(res,400,{error:m});
   if(r!='r')return send(res,401,{error:'Não autorizado'});if(!c||!n||Math.abs(n)>100000)return bad('Dados inválidos');if(note.length<3)return bad('Informe o motivo do ajuste');
   if(n<0&&-n>lstate(c.id).bal)return bad('O ajuste deixaria o saldo negativo');
   addP(c.id,'adjust',n,null,note,'Restaurante',n>0?expAt():undefined);D.audit.push({t:Date.now(),by:'Restaurante',ev:'Ajuste de '+n+' ponto(s) para '+c.name+': '+note});save();return send(res,200,{ok:1})}
  if(p=='/api/pay'&&M=='POST'){
   const b=await readBody(req),o=D.orders[b.id],tx=String(b.tx||'').slice(0,80);if(r!='r')return send(res,401,{error:'Não autorizado'});if(!o||!o.pay)return send(res,404,{error:'Pedido não encontrado'});
   if(b.act=='paid'&&o.pay.st=='pendente'&&o.status!='cancelado'){o.pay.st='pago';o.pay.paid=o.total;o.pay.tx=tx;o.pay.at=Date.now();hist(o,'Pagamento confirmado','Restaurante',tx||undefined)}
   else if(b.act=='refunded'&&o.pay.st=='estornar'){o.pay.st='estornado';o.pay.refTx=tx;hist(o,'Reembolso registrado','Restaurante',tx||undefined)}
   else return send(res,400,{error:'Ação inválida para a situação atual do pagamento'});
   save();notify();return send(res,200,o)}
  if(p=='/api/status'&&M=='POST'){
   const b=await readBody(req),o=D.orders[b.id],to=b.to,why=String(b.why||'').trim().slice(0,300);
   if(r!='r')return send(res,401,{error:'Não autorizado'});if(!o)return send(res,404,{error:'Pedido não encontrado'});
   if(!LBL[to]||to==o.status)return send(res,400,{error:'Status inválido'});
   if(o.status=='cancelado')return send(res,400,{error:'Pedido cancelado não pode ser reaberto'});
   const back=to!='cancelado'&&ORD.indexOf(to)<ORD.indexOf(o.status);
   if((back||to=='cancelado')&&why.length<3)return send(res,400,{error:'Informe o motivo (mínimo 3 caracteres)'});
   if((to=='a_caminho'||(to=='entregue'&&o.fulfillment=='delivery'))&&!o.courier)return send(res,400,{error:'Atribua um entregador antes'});
   const prev=o.status;o.status=to;
   if(back){if(prev=='a_caminho'||prev=='entregue')delete o.cl;if(prev=='entregue')delete o.dt;if(to=='novo')delete o.courier}
   if(to=='entregue')o.dt=Date.now();if(to=='cancelado'){o.cancel={why,by:'Restaurante',t:Date.now()};delete o.cl}
   hist(o,LBL[prev]+' → '+LBL[to],'Restaurante',why);loyHook(o,prev,to);payHook(o,prev,to);save();notify();return send(res,200,o)}
  if(p=='/api/duty'&&M=='POST'){const b=await readBody(req);if(r!='e')return send(res,401,{error:'Não autorizado'});W.c.duty=!!b.on;if(!b.on)delete W.c.loc;save();notify();return send(res,200,{ok:1})}
  if(p=='/api/courier'&&M=='POST'){
   const b=await readBody(req);if(r!='r')return send(res,401,{error:'Não autorizado'});
   if(b.del){D.couriers=D.couriers.filter(c=>c.id!=b.id);save();notify();return send(res,200,{ok:1})}
   const name=String(b.name||'').trim().slice(0,40),pin=String(b.pin||'').trim();let c=D.couriers.find(c=>c.id==b.id);
   if(!name)return send(res,400,{error:'Informe o nome'});
   if(!c&&pin.length<4)return send(res,400,{error:'O PIN precisa ter ao menos 4 caracteres'});
   if(pin&&(pin.length<4||pin==ST().pinR||D.couriers.some(x=>x.pin==pin&&x!==c)))return send(res,400,{error:'PIN inválido ou já em uso'});
   if(!c){c={id:'m'+Date.now().toString(36),on:true};D.couriers.push(c)}
   c.name=name;c.phone=String(b.phone||'').slice(0,30);if(pin)c.pin=pin;if(typeof b.on=='boolean')c.on=b.on;save();notify();return send(res,200,{ok:1})}
  if(p=='/api/assign'&&M=='POST'){
   const b=await readBody(req);if(r!='r')return send(res,401,{error:'Não autorizado'});
   const c=b.courier?D.couriers.find(c=>c.id==b.courier&&c.on):null;if(b.courier&&!c)return send(res,400,{error:'Motoboy inválido'});
   let n=0;(Array.isArray(b.ids)?b.ids:[]).forEach(id=>{const o=D.orders[id];if(o&&['preparando','pronto'].includes(o.status)){if(c)o.courier=c.id;else delete o.courier;hist(o,c?'Entregador atribuído: '+c.name:'Entregador removido','Restaurante');n++}});
   save();notify();return send(res,200,{n})}
  if(p=='/api/orders'&&M=='DELETE'){if(r!='r')return send(res,401,{error:'Não autorizado'});D.orders={};save();notify();return send(res,200,{ok:1})}
  if(p=='/api/audio'&&M=='POST'){
   const b=await readBody(req,MAXB*2);if(r!='r')return send(res,401,{error:'Não autorizado'});
   const m=/^data:[a-z0-9\/.+\-]*;base64,([A-Za-z0-9+\/=]+)$/.exec(b.data||'');if(!m)return send(res,400,{error:'Arquivo inválido'});
   const buf=Buffer.from(m[1],'base64');if(buf.length>MAXB)return send(res,400,{error:'Arquivo acima de '+MAXB/1e6+' MB'});
   const hd=buf.slice(0,12),k=hd.slice(0,3).toString()=='ID3'||(hd[0]==0xFF&&(hd[1]&0xE0)==0xE0)?'mp3':hd.slice(0,4).toString()=='RIFF'&&hd.slice(8,12).toString()=='WAVE'?'wav':hd.slice(0,4).toString()=='OggS'?'ogg':hd.slice(4,8).toString()=='ftyp'?'mp4':null;
   if(!k)return send(res,400,{error:'Formato não reconhecido. Envie MP3, WAV, OGG ou MP4 com áudio.'});
   const id=rnd(),cp=require('child_process'),ff=cp.spawnSync('ffmpeg',['-version']).status===0;
   if(!ff&&k=='mp4')return send(res,400,{error:'Para usar MP4 o servidor precisa do ffmpeg instalado. Envie MP3, WAV ou OGG.'});
   if(!ff&&buf.length>1.5e6)return send(res,400,{error:'Arquivo acima de 1,5 MB (sem ffmpeg o servidor não consegue encurtá-lo).'});
   let n=id+'.'+k;
   if(ff){const tin=path.join(UP,'tmp_'+id+'.'+k);fs.writeFileSync(tin,buf);n=id+'.mp3';const o=cp.spawnSync('ffmpeg',['-y','-i',tin,'-vn','-t',String(MAXS),'-ac','2','-b:a','128k',path.join(UP,n)],{timeout:30000});fs.unlinkSync(tin);
    if(o.status!==0||!fs.existsSync(path.join(UP,n)))return send(res,400,{error:'Não foi possível extrair o áudio (arquivo sem faixa de áudio ou corrompido).'})}
   else fs.writeFileSync(path.join(UP,n),buf);
   return send(res,200,{id,name:String(b.name||'som').slice(0,60),url:'/uploads/'+n})}
  if(p=='/api/img'&&M=='POST'){const b=await readBody(req,3e6);if(r!='r')return send(res,401,{error:'Não autorizado'});const m=/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+\/=]+)$/.exec(b.data||'');if(!m||m[2].length>3.5e6)return send(res,400,{error:'Imagem inválida ou muito grande'});
   const buf=Buffer.from(m[2],'base64'),mg={jpeg:buf[0]==0xFF&&buf[1]==0xD8,png:buf.slice(1,4).toString()=='PNG',webp:buf.slice(0,4).toString()=='RIFF'&&buf.slice(8,12).toString()=='WEBP'};
   if(!mg[m[1]])return send(res,400,{error:'O arquivo não é uma imagem válida'});
   const n=rnd()+'.'+(m[1]=='jpeg'?'jpg':m[1]);fs.writeFileSync(path.join(UP,n),buf);return send(res,200,{url:'/uploads/'+n})}
  if(p.startsWith('/uploads/')){const n=p.slice(9),f=path.join(UP,n),ext=(n.match(/\.([a-z0-9]+)$/)||[])[1],MT={jpg:'image/jpeg',png:'image/png',webp:'image/webp',mp3:'audio/mpeg',wav:'audio/wav',ogg:'audio/ogg'};
   if(!/^[a-z0-9]+\.[a-z0-9]+$/.test(n)||!MT[ext]||!fs.existsSync(f))return send(res,404,{error:'Não encontrado'});res.writeHead(200,{'content-type':MT[ext],'cache-control':'public,max-age=31536000'});return fs.createReadStream(f).pipe(res)}
  if(p=='/api/review'&&M=='POST'){
   const b=await readBody(req),bad=m=>send(res,400,{error:m});
   const o=D.orders[b.orderId];if(!o)return bad('Pedido não encontrado');
   if(o.status!='entregue')return bad('Só é possível avaliar pedidos já entregues');
   if(o.cid!=cid&&(!U||o.uid!=U.id))return send(res,403,{error:'Você só pode avaliar seus próprios pedidos'});
   const fr=Math.min(5,Math.max(1,Math.round(+b.foodRating||0)));
   const dr=Math.min(5,Math.max(1,Math.round(+b.deliveryRating||0)));
   if(!fr||!dr)return bad('Informe a nota de 1 a 5 estrelas');
   const comment=String(b.comment||'').trim().slice(0,500);
   D.reviews=D.reviews||[];
   let rev=D.reviews.find(x=>x.orderId==o.id);
   const cou=o.courier?D.couriers.find(c=>c.id==o.courier):null;
   if(rev){
    rev.foodRating=fr;rev.deliveryRating=dr;rev.comment=comment;rev.updatedAt=Date.now();
   }else{
    rev={
     id:'rv'+Date.now().toString(36)+Math.random().toString(36).slice(2,5),
     orderId:o.id,
     orderNum:o.num,
     uid:o.uid||null,
     customerName:o.name,
     foodRating:fr,
     deliveryRating:dr,
     comment,
     courierId:o.courier||null,
     courierName:cou?cou.name:null,
     createdAt:Date.now(),
     hidden:false
    };
    D.reviews.push(rev);
   }
   o.reviewed=rev.id;
   save();notify();return send(res,200,rev);
  }
  if(p=='/api/review/hide'&&M=='POST'){
   const b=await readBody(req);if(r!='r')return send(res,401,{error:'Não autorizado'});
   const rev=(D.reviews||[]).find(x=>x.id==b.id);if(!rev)return send(res,404,{error:'Avaliação não encontrada'});
   rev.hidden=!!b.hidden;
   D.audit.push({t:Date.now(),by:'Restaurante',ev:(rev.hidden?'Ocultou':'Reexibiu')+' avaliação do pedido #'+rev.orderNum});
   save();notify();return send(res,200,{ok:1,hidden:rev.hidden});
  }
  if(p=='/api/route'){try{return send(res,200,await route(u.searchParams.get('from'),u.searchParams.get('to')))}catch(e){return send(res,200,{})}}
  if(p.startsWith('/api/'))return send(res,404,{error:'Não encontrado'});
  if(p=='/empresa/admin'||p=='/empresa/admin.html'){res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-cache'});return fs.createReadStream(path.join(__dirname,'public','empresa-admin.html')).pipe(res)}
  if(p=='/empresa'||p=='/empresa.html'){res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-cache'});return fs.createReadStream(path.join(__dirname,'public','empresa.html')).pipe(res)}
  res.writeHead(200,{'content-type':'text/html; charset=utf-8'});fs.createReadStream(HTML).pipe(res);
 }catch(e){send(res,500,{error:'Erro interno'})}
}).listen(PORT,()=>console.log('PedeAí rodando em http://localhost:'+PORT));
