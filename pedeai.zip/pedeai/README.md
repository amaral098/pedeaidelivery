# PedeAí
Requer Node.js 18+. Sem dependências.
1. Edite `public/index.html` e troque `COLE_SUA_CHAVE_LOCATIONIQ` pela sua chave do LocationIQ.
2. `node server.js` (porta 3000; mude com a variável PORT).
3. Publique atrás de HTTPS (Nginx/Caddy): o GPS do celular só funciona em HTTPS.
Páginas: `/` (cliente), `/empresa` (apresentação comercial), `/empresa/admin` (administração comercial), `/#restaurante` e `/#entregador`. No painel do restaurante, a aba **PDV** permite lançar pedidos de mesa, retirada ou entrega, registrar pagamento e imprimir a comanda. A aba **Aparência** permite personalizar cores e logotipo e configurar templates independentes para a loja e para a gestão. A loja tem os modelos cardápio clássico (cabeçalho limpo e categorias à esquerda), vitrine da casa (marca e categorias centralizadas, com fotos maiores) e pedido rápido (categorias fixas durante a navegação e lista compacta). A gestão oferece sete layouts: clássico, central de operação, compacto, vitrine visual, central de delivery, painel de gestão e balcão e salão. Os layouts da gestão reorganizam os indicadores, pedidos, cardápio e menus internos, sem alterar o template público escolhido para a loja. Os dados da empresa são independentes dos restaurantes e podem ser editados em `/empresa/admin`; configure `COMPANY_ADMIN_PASSWORD` com uma senha de pelo menos 12 caracteres antes de iniciar o servidor. No PowerShell: `$env:COMPANY_ADMIN_PASSWORD='use-uma-senha-forte-com-12-ou-mais-caracteres'; node server.js`. Essa senha não é o PIN dos restaurantes. PINs iniciais: 1234 e 0000 (troque em Configurações).
Dados dos restaurantes salvos em `data.json` e conteúdo comercial em `company.json` (faça backup de ambos).

## Login com Google (opcional)
Crie um ID de cliente OAuth (tipo Web) em console.cloud.google.com, adicione seu domínio em 'Origens JavaScript autorizadas' e inicie com:
`GOOGLE_CLIENT_ID=seu-id.apps.googleusercontent.com node server.js` (Windows PowerShell: `$env:GOOGLE_CLIENT_ID='...'; node server.js`).
